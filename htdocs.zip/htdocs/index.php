<?php
session_start();

// Autoload
require_once __DIR__ . '/config/database.php';

// Helpers
function redirect($url) {
    header("Location: index.php?page=$url");
    exit;
}

function isLoggedIn() {
    return isset($_SESSION['user']);
}

function getRole() {
    return $_SESSION['user']['role'] ?? '';
}

function checkRole($allowedRoles) {
    if (!isLoggedIn()) {
        header("Location: index.php?page=login");
        exit;
    }
    if (!in_array(getRole(), $allowedRoles)) {
        http_response_code(403);
        echo "<h2>403 - Akses Ditolak</h2><p>Anda tidak memiliki akses ke halaman ini.</p>";
        echo '<a href="index.php?page=dashboard">Kembali ke Dashboard</a>';
        exit;
    }
}

function flash($key, $message = null) {
    if ($message) {
        $_SESSION['flash'][$key] = $message;
    } else {
        $msg = $_SESSION['flash'][$key] ?? null;
        unset($_SESSION['flash'][$key]);
        return $msg;
    }
}

// Router
$page = $_GET['page'] ?? 'login';
$action = $_GET['action'] ?? 'index';
$id = $_GET['id'] ?? null;

switch ($page) {
    case 'login':
    case 'logout':
        require_once __DIR__ . '/controllers/AuthController.php';
        $controller = new AuthController();
        if ($page === 'login') $controller->login();
        if ($page === 'logout') $controller->logout();
        break;

    case 'dashboard':
        require_once __DIR__ . '/controllers/DashboardController.php';
        $controller = new DashboardController();
        $controller->index();
        break;

    case 'user':
        require_once __DIR__ . '/controllers/UserController.php';
        $controller = new UserController();
        if ($action === 'index') $controller->index();
        elseif ($action === 'create') $controller->create();
        elseif ($action === 'store') $controller->store();
        elseif ($action === 'edit') $controller->edit($id);
        elseif ($action === 'update') $controller->update($id);
        elseif ($action === 'delete') $controller->delete($id);
        break;

    case 'tarif':
        require_once __DIR__ . '/controllers/TarifController.php';
        $controller = new TarifController();
        if ($action === 'index') $controller->index();
        elseif ($action === 'create') $controller->create();
        elseif ($action === 'store') $controller->store();
        elseif ($action === 'edit') $controller->edit($id);
        elseif ($action === 'update') $controller->update($id);
        elseif ($action === 'delete') $controller->delete($id);
        break;

    case 'area_parkir':
        require_once __DIR__ . '/controllers/AreaParkirController.php';
        $controller = new AreaParkirController();
        if ($action === 'index') $controller->index();
        elseif ($action === 'create') $controller->create();
        elseif ($action === 'store') $controller->store();
        elseif ($action === 'edit') $controller->edit($id);
        elseif ($action === 'update') $controller->update($id);
        elseif ($action === 'delete') $controller->delete($id);
        break;

    case 'kendaraan':
        require_once __DIR__ . '/controllers/KendaraanController.php';
        $controller = new KendaraanController();
        if ($action === 'index') $controller->index();
        elseif ($action === 'create') $controller->create();
        elseif ($action === 'store') $controller->store();
        elseif ($action === 'edit') $controller->edit($id);
        elseif ($action === 'update') $controller->update($id);
        elseif ($action === 'delete') $controller->delete($id);
        break;

    case 'log':
        require_once __DIR__ . '/controllers/LogController.php';
        $controller = new LogController();
        $controller->index();
        break;

    case 'transaksi':
        require_once __DIR__ . '/controllers/TransaksiController.php';
        $controller = new TransaksiController();
        if ($action === 'index') $controller->index();
        elseif ($action === 'create') $controller->create();
        elseif ($action === 'store') $controller->store();
        elseif ($action === 'keluar') $controller->keluar($id);
        elseif ($action === 'proses_keluar') $controller->prosesKeluar($id);
        elseif ($action === 'struk') $controller->struk($id);
        break;

    case 'rekap':
        require_once __DIR__ . '/controllers/RekapController.php';
        $controller = new RekapController();
        $controller->index();
        break;

    default:
        echo "<h2>404 - Halaman tidak ditemukan</h2>";
        break;
}
