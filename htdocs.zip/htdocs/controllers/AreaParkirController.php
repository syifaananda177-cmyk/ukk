<?php
require_once __DIR__ . '/../models/AreaParkir.php';
require_once __DIR__ . '/../models/LogAktivitas.php';

class AreaParkirController {
    private $model;
    private $logModel;

    public function __construct() {
        checkRole(['admin']);
        $this->model = new AreaParkir();
        $this->logModel = new LogAktivitas();
    }

    public function index() {
        $areas = $this->model->getAll();
        require_once __DIR__ . '/../views/area_parkir/index.php';
    }

    public function create() {
        require_once __DIR__ . '/../views/area_parkir/create.php';
    }

    public function store() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $data = [
                'nama_area' => trim($_POST['nama_area']),
                'kapasitas' => (int)$_POST['kapasitas'],
                'terisi' => 0,
            ];
            $this->model->create($data);
            $this->logModel->create($_SESSION['user']['id_user'], 'Menambahkan area parkir: ' . $data['nama_area']);
            flash('success', 'Area parkir berhasil ditambahkan!');
            header("Location: index.php?page=area_parkir");
            exit;
        }
    }

    public function edit($id) {
        $area = $this->model->getById($id);
        if (!$area) {
            flash('error', 'Area parkir tidak ditemukan!');
            header("Location: index.php?page=area_parkir");
            exit;
        }
        require_once __DIR__ . '/../views/area_parkir/edit.php';
    }

    public function update($id) {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $data = [
                'nama_area' => trim($_POST['nama_area']),
                'kapasitas' => (int)$_POST['kapasitas'],
                'terisi' => (int)$_POST['terisi'],
            ];
            $this->model->update($id, $data);
            $this->logModel->create($_SESSION['user']['id_user'], 'Mengupdate area parkir ID: ' . $id);
            flash('success', 'Area parkir berhasil diupdate!');
            header("Location: index.php?page=area_parkir");
            exit;
        }
    }

    public function delete($id) {
        $this->model->delete($id);
        $this->logModel->create($_SESSION['user']['id_user'], 'Menghapus area parkir ID: ' . $id);
        flash('success', 'Area parkir berhasil dihapus!');
        header("Location: index.php?page=area_parkir");
        exit;
    }
}
