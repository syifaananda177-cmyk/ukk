<?php
require_once __DIR__ . '/../models/Tarif.php';
require_once __DIR__ . '/../models/LogAktivitas.php';

class TarifController {
    private $model;
    private $logModel;

    public function __construct() {
        checkRole(['admin']);
        $this->model = new Tarif();
        $this->logModel = new LogAktivitas();
    }

    public function index() {
        $tarifs = $this->model->getAll();
        require_once __DIR__ . '/../views/tarif/index.php';
    }

    public function create() {
        require_once __DIR__ . '/../views/tarif/create.php';
    }

    public function store() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $data = [
                'jenis_kendaraan' => $_POST['jenis_kendaraan'],
                'tarif_per_jam' => $_POST['tarif_per_jam'],
            ];
            $this->model->create($data);
            $this->logModel->create($_SESSION['user']['id_user'], 'Menambahkan tarif: ' . $data['jenis_kendaraan']);
            flash('success', 'Tarif berhasil ditambahkan!');
            header("Location: index.php?page=tarif");
            exit;
        }
    }

    public function edit($id) {
        $tarif = $this->model->getById($id);
        if (!$tarif) {
            flash('error', 'Tarif tidak ditemukan!');
            header("Location: index.php?page=tarif");
            exit;
        }
        require_once __DIR__ . '/../views/tarif/edit.php';
    }

    public function update($id) {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $data = [
                'jenis_kendaraan' => $_POST['jenis_kendaraan'],
                'tarif_per_jam' => $_POST['tarif_per_jam'],
            ];
            $this->model->update($id, $data);
            $this->logModel->create($_SESSION['user']['id_user'], 'Mengupdate tarif ID: ' . $id);
            flash('success', 'Tarif berhasil diupdate!');
            header("Location: index.php?page=tarif");
            exit;
        }
    }

    public function delete($id) {
        $this->model->delete($id);
        $this->logModel->create($_SESSION['user']['id_user'], 'Menghapus tarif ID: ' . $id);
        flash('success', 'Tarif berhasil dihapus!');
        header("Location: index.php?page=tarif");
        exit;
    }
}
