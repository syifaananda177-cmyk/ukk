<?php
require_once __DIR__ . '/../models/Transaksi.php';

class RekapController {
    private $model;

    public function __construct() {
        checkRole(['owner']);
        $this->model = new Transaksi();
    }

    public function index() {
        $tanggalMulai = $_GET['tanggal_mulai'] ?? date('Y-m-01');
        $tanggalSelesai = $_GET['tanggal_selesai'] ?? date('Y-m-d');
        $transaksis = $this->model->getRekap($tanggalMulai, $tanggalSelesai);
        $totalPendapatan = $this->model->getTotalPendapatan($tanggalMulai, $tanggalSelesai);
        require_once __DIR__ . '/../views/rekap/index.php';
    }
}
