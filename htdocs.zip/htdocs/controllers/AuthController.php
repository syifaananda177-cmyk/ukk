<?php
require_once __DIR__ . '/../models/User.php';
require_once __DIR__ . '/../models/LogAktivitas.php';

class AuthController {
    private $userModel;
    private $logModel;

    public function __construct() {
        $this->userModel = new User();
        $this->logModel = new LogAktivitas();
    }

    public function login() {
        if (isLoggedIn()) {
            header("Location: index.php?page=dashboard");
            exit;
        }

        $error = '';
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $username = trim($_POST['username'] ?? '');
            $password = trim($_POST['password'] ?? '');

            if (empty($username) || empty($password)) {
                $error = 'Username dan password harus diisi!';
            } else {
                $user = $this->userModel->login($username, $password);
                if ($user) {
                    $_SESSION['user'] = $user;
                    $this->logModel->create($user['id_user'], 'Login ke sistem');
                    header("Location: index.php?page=dashboard");
                    exit;
                } else {
                    $error = 'Username atau password salah!';
                }
            }
        }
        require_once __DIR__ . '/../views/auth/login.php';
    }

    public function logout() {
        if (isLoggedIn()) {
            $this->logModel->create($_SESSION['user']['id_user'], 'Logout dari sistem');
        }
        session_destroy();
        header("Location: index.php?page=login");
        exit;
    }
}
