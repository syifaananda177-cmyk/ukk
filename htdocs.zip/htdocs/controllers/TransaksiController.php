<?php
require_once __DIR__ . '/../models/Transaksi.php';
require_once __DIR__ . '/../models/Kendaraan.php';
require_once __DIR__ . '/../models/Tarif.php';
require_once __DIR__ . '/../models/AreaParkir.php';
require_once __DIR__ . '/../models/LogAktivitas.php';

class TransaksiController {
    private $model;
    private $kendaraanModel;
    private $tarifModel;
    private $areaModel;
    private $logModel;

    public function __construct() {
        checkRole(['petugas']);
        $this->model = new Transaksi();
        $this->kendaraanModel = new Kendaraan();
        $this->tarifModel = new Tarif();
        $this->areaModel = new AreaParkir();
        $this->logModel = new LogAktivitas();
    }

    public function index() {
        $transaksis = $this->model->getAll();
        $transaksiAktif = $this->model->getAktif();
        require_once __DIR__ . '/../views/transaksi/index.php';
    }

    public function create() {
        $kendaraans = $this->kendaraanModel->getAll();
        $tarifs = $this->tarifModel->getAll();
        $areas = $this->areaModel->getAll();
        require_once __DIR__ . '/../views/transaksi/create.php';
    }

    public function store() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $data = [
                'id_kendaraan' => $_POST['id_kendaraan'],
                'waktu_masuk' => date('Y-m-d H:i:s'),
                'id_tarif' => $_POST['id_tarif'],
                'id_user' => $_SESSION['user']['id_user'],
                'id_area' => $_POST['id_area'],
            ];

            $idParkir = $this->model->create($data);
            if ($idParkir) {
                $this->areaModel->incrementTerisi($data['id_area']);
                $kendaraan = $this->kendaraanModel->getById($data['id_kendaraan']);
                $this->logModel->create($_SESSION['user']['id_user'], 'Kendaraan masuk: ' . $kendaraan['plat_nomor']);
                flash('success', 'Kendaraan berhasil masuk parkir!');
                header("Location: index.php?page=transaksi&action=struk&id=$idParkir");
                exit;
            }
        }
    }

    public function keluar($id) {
        $transaksi = $this->model->getById($id);
        if (!$transaksi || $transaksi['status'] !== 'masuk') {
            flash('error', 'Transaksi tidak valid!');
            header("Location: index.php?page=transaksi");
            exit;
        }

        $waktuKeluar = date('Y-m-d H:i:s');
        $waktuMasuk = strtotime($transaksi['waktu_masuk']);
        $selisihJam = max(1, ceil((strtotime($waktuKeluar) - $waktuMasuk) / 3600));
        $biaya = $selisihJam * $transaksi['tarif_per_jam'];

        $data = [
            'transaksi' => $transaksi,
            'waktu_keluar' => $waktuKeluar,
            'durasi' => $selisihJam,
            'biaya' => $biaya,
        ];
        require_once __DIR__ . '/../views/transaksi/keluar.php';
    }

    public function prosesKeluar($id) {
        $transaksi = $this->model->getById($id);
        if (!$transaksi || $transaksi['status'] !== 'masuk') {
            flash('error', 'Transaksi tidak valid!');
            header("Location: index.php?page=transaksi");
            exit;
        }

        $waktuKeluar = date('Y-m-d H:i:s');
        $waktuMasuk = strtotime($transaksi['waktu_masuk']);
        $selisihJam = max(1, ceil((strtotime($waktuKeluar) - $waktuMasuk) / 3600));
        $biaya = $selisihJam * $transaksi['tarif_per_jam'];

        $this->model->prosesKeluar($id, $waktuKeluar, $selisihJam, $biaya);
        $this->areaModel->decrementTerisi($transaksi['id_area']);
        $this->logModel->create($_SESSION['user']['id_user'], 'Kendaraan keluar: ' . $transaksi['plat_nomor'] . ' - Biaya: Rp ' . number_format($biaya));

        flash('success', 'Kendaraan berhasil keluar! Biaya: Rp ' . number_format($biaya));
        header("Location: index.php?page=transaksi&action=struk&id=$id");
        exit;
    }

    public function struk($id) {
        $transaksi = $this->model->getById($id);
        if (!$transaksi) {
            flash('error', 'Transaksi tidak ditemukan!');
            header("Location: index.php?page=transaksi");
            exit;
        }
        require_once __DIR__ . '/../views/transaksi/struk.php';
    }
}
