<?php
require_once __DIR__ . '/../models/Kendaraan.php';
require_once __DIR__ . '/../models/User.php';
require_once __DIR__ . '/../models/LogAktivitas.php';

class KendaraanController {
    private $model;
    private $logModel;
    private $userModel;

    public function __construct() {
        checkRole(['admin']);
        $this->model = new Kendaraan();
        $this->logModel = new LogAktivitas();
        $this->userModel = new User();
    }

    public function index() {
        $kendaraans = $this->model->getAll();
        require_once __DIR__ . '/../views/kendaraan/index.php';
    }

    public function create() {
        $users = $this->userModel->getAll();
        require_once __DIR__ . '/../views/kendaraan/create.php';
    }

    public function store() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $data = [
                'plat_nomor' => strtoupper(trim($_POST['plat_nomor'])),
                'jenis_kendaraan' => $_POST['jenis_kendaraan'],
                'warna' => trim($_POST['warna']),
                'pemilik' => trim($_POST['pemilik']),
                'id_user' => $_POST['id_user'],
            ];
            $this->model->create($data);
            $this->logModel->create($_SESSION['user']['id_user'], 'Menambahkan kendaraan: ' . $data['plat_nomor']);
            flash('success', 'Kendaraan berhasil ditambahkan!');
            header("Location: index.php?page=kendaraan");
            exit;
        }
    }

    public function edit($id) {
        $kendaraan = $this->model->getById($id);
        $users = $this->userModel->getAll();
        if (!$kendaraan) {
            flash('error', 'Kendaraan tidak ditemukan!');
            header("Location: index.php?page=kendaraan");
            exit;
        }
        require_once __DIR__ . '/../views/kendaraan/edit.php';
    }

    public function update($id) {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $data = [
                'plat_nomor' => strtoupper(trim($_POST['plat_nomor'])),
                'jenis_kendaraan' => $_POST['jenis_kendaraan'],
                'warna' => trim($_POST['warna']),
                'pemilik' => trim($_POST['pemilik']),
                'id_user' => $_POST['id_user'],
            ];
            $this->model->update($id, $data);
            $this->logModel->create($_SESSION['user']['id_user'], 'Mengupdate kendaraan ID: ' . $id);
            flash('success', 'Kendaraan berhasil diupdate!');
            header("Location: index.php?page=kendaraan");
            exit;
        }
    }

    public function delete($id) {
        $this->model->delete($id);
        $this->logModel->create($_SESSION['user']['id_user'], 'Menghapus kendaraan ID: ' . $id);
        flash('success', 'Kendaraan berhasil dihapus!');
        header("Location: index.php?page=kendaraan");
        exit;
    }
}
