<?php
require_once __DIR__ . '/../models/Transaksi.php';
require_once __DIR__ . '/../models/User.php';
require_once __DIR__ . '/../models/Kendaraan.php';
require_once __DIR__ . '/../models/AreaParkir.php';

class DashboardController {
    public function index() {
        if (!isLoggedIn()) {
            header("Location: index.php?page=login");
            exit;
        }

        $role = getRole();
        $transaksiModel = new Transaksi();
        $userModel = new User();
        $kendaraanModel = new Kendaraan();
        $areaParkirModel = new AreaParkir();

        $data = [
            'total_transaksi' => $transaksiModel->countAll(),
            'transaksi_aktif' => $transaksiModel->countAktif(),
            'pendapatan_hari_ini' => $transaksiModel->totalPendapatanHariIni(),
            'total_user' => $userModel->countAll(),
            'total_kendaraan' => $kendaraanModel->countAll(),
            'areas' => $areaParkirModel->getAll(),
        ];

        if ($role === 'admin') {
            require_once __DIR__ . '/../views/dashboard/admin.php';
        } elseif ($role === 'petugas') {
            require_once __DIR__ . '/../views/dashboard/petugas.php';
        } elseif ($role === 'owner') {
            require_once __DIR__ . '/../views/dashboard/owner.php';
        }
    }
}
