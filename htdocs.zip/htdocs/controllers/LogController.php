<?php
require_once __DIR__ . '/../models/LogAktivitas.php';

class LogController {
    private $model;

    public function __construct() {
        checkRole(['admin']);
        $this->model = new LogAktivitas();
    }

    public function index() {
        $logs = $this->model->getAll();
        require_once __DIR__ . '/../views/log/index.php';
    }
}
