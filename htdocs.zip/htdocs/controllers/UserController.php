<?php
require_once __DIR__ . '/../models/User.php';
require_once __DIR__ . '/../models/LogAktivitas.php';

class UserController {
    private $model;
    private $logModel;

    public function __construct() {
        checkRole(['admin']);
        $this->model = new User();
        $this->logModel = new LogAktivitas();
    }

    public function index() {
        $users = $this->model->getAll();
        require_once __DIR__ . '/../views/user/index.php';
    }

    public function create() {
        require_once __DIR__ . '/../views/user/create.php';
    }

    public function store() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $data = [
                'nama_lengkap' => trim($_POST['nama_lengkap']),
                'username' => trim($_POST['username']),
                'password' => trim($_POST['password']),
                'role' => $_POST['role'],
                'status_aktif' => isset($_POST['status_aktif']) ? 1 : 0,
            ];
            $this->model->create($data);
            $this->logModel->create($_SESSION['user']['id_user'], 'Menambahkan user: ' . $data['username']);
            flash('success', 'User berhasil ditambahkan!');
            header("Location: index.php?page=user");
            exit;
        }
    }

    public function edit($id) {
        $user = $this->model->getById($id);
        if (!$user) {
            flash('error', 'User tidak ditemukan!');
            header("Location: index.php?page=user");
            exit;
        }
        require_once __DIR__ . '/../views/user/edit.php';
    }

    public function update($id) {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $data = [
                'nama_lengkap' => trim($_POST['nama_lengkap']),
                'username' => trim($_POST['username']),
                'password' => trim($_POST['password']),
                'role' => $_POST['role'],
                'status_aktif' => isset($_POST['status_aktif']) ? 1 : 0,
            ];
            $this->model->update($id, $data);
            $this->logModel->create($_SESSION['user']['id_user'], 'Mengupdate user ID: ' . $id);
            flash('success', 'User berhasil diupdate!');
            header("Location: index.php?page=user");
            exit;
        }
    }

    public function delete($id) {
        $this->model->delete($id);
        $this->logModel->create($_SESSION['user']['id_user'], 'Menghapus user ID: ' . $id);
        flash('success', 'User berhasil dihapus!');
        header("Location: index.php?page=user");
        exit;
    }
}
