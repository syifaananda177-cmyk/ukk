<?php $pageTitle = 'Tarif Parkir'; require_once __DIR__ . '/../layouts/header.php'; ?>

<div class="card-custom">
    <div class="card-header-custom">
        <h5><i class="bi bi-tags-fill"></i> Data Tarif Parkir</h5>
        <a href="index.php?page=tarif&action=create" class="btn-primary-custom"><i class="bi bi-plus-lg"></i> Tambah Tarif</a>
    </div>
    <div class="card-body-custom" style="overflow-x:auto;">
        <table class="table-custom">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Jenis Kendaraan</th>
                    <th>Tarif / Jam</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $no = 1; foreach ($tarifs as $t): ?>
                <tr>
                    <td><?= $no++ ?></td>
                    <td><span class="badge-custom badge-info"><?= ucfirst($t['jenis_kendaraan']) ?></span></td>
                    <td><strong>Rp <?= number_format($t['tarif_per_jam']) ?></strong></td>
                    <td>
                        <div class="btn-group-action">
                            <a href="index.php?page=tarif&action=edit&id=<?= $t['id_tarif'] ?>" class="btn-warning-custom"><i class="bi bi-pencil"></i></a>
                            <a href="index.php?page=tarif&action=delete&id=<?= $t['id_tarif'] ?>" class="btn-danger-custom" onclick="return confirm('Yakin hapus tarif ini?')"><i class="bi bi-trash"></i></a>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php if (empty($tarifs)): ?>
                <tr><td colspan="4" class="text-center py-4" style="color:#94a3b8;">Belum ada data tarif</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once __DIR__ . '/../layouts/footer.php'; ?>
