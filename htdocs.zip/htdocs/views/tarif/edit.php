<?php $pageTitle = 'Edit Tarif'; require_once __DIR__ . '/../layouts/header.php'; ?>

<div class="card-custom" style="max-width:500px;">
    <div class="card-header-custom">
        <h5><i class="bi bi-pencil-square"></i> Edit Tarif</h5>
    </div>
    <div class="card-body-custom">
        <form method="POST" action="index.php?page=tarif&action=update&id=<?= $tarif['id_tarif'] ?>" class="form-custom">
            <div class="form-group">
                <label>Jenis Kendaraan</label>
                <select name="jenis_kendaraan" class="form-select" required>
                    <option value="motor" <?= $tarif['jenis_kendaraan'] === 'motor' ? 'selected' : '' ?>>Motor</option>
                    <option value="mobil" <?= $tarif['jenis_kendaraan'] === 'mobil' ? 'selected' : '' ?>>Mobil</option>
                    <option value="lainnya" <?= $tarif['jenis_kendaraan'] === 'lainnya' ? 'selected' : '' ?>>Lainnya</option>
                </select>
            </div>
            <div class="form-group">
                <label>Tarif Per Jam (Rp)</label>
                <input type="number" name="tarif_per_jam" class="form-control" required min="0" value="<?= $tarif['tarif_per_jam'] ?>">
            </div>
            <div class="d-flex gap-2">
                <button type="submit" class="btn-primary-custom"><i class="bi bi-save"></i> Update</button>
                <a href="index.php?page=tarif" class="btn-secondary-custom"><i class="bi bi-arrow-left"></i> Kembali</a>
            </div>
        </form>
    </div>
</div>

<?php require_once __DIR__ . '/../layouts/footer.php'; ?>
