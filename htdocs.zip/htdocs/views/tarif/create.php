<?php $pageTitle = 'Tambah Tarif'; require_once __DIR__ . '/../layouts/header.php'; ?>

<div class="card-custom" style="max-width:500px;">
    <div class="card-header-custom">
        <h5><i class="bi bi-plus-circle-fill"></i> Tambah Tarif Baru</h5>
    </div>
    <div class="card-body-custom">
        <form method="POST" action="index.php?page=tarif&action=store" class="form-custom">
            <div class="form-group">
                <label>Jenis Kendaraan</label>
                <select name="jenis_kendaraan" class="form-select" required>
                    <option value="">-- Pilih Jenis --</option>
                    <option value="motor">Motor</option>
                    <option value="mobil">Mobil</option>
                    <option value="lainnya">Lainnya</option>
                </select>
            </div>
            <div class="form-group">
                <label>Tarif Per Jam (Rp)</label>
                <input type="number" name="tarif_per_jam" class="form-control" required min="0" placeholder="Contoh: 5000">
            </div>
            <div class="d-flex gap-2">
                <button type="submit" class="btn-primary-custom"><i class="bi bi-save"></i> Simpan</button>
                <a href="index.php?page=tarif" class="btn-secondary-custom"><i class="bi bi-arrow-left"></i> Kembali</a>
            </div>
        </form>
    </div>
</div>

<?php require_once __DIR__ . '/../layouts/footer.php'; ?>
