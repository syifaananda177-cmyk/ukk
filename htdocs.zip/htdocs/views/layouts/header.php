<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SIMPAR - Sistem Manajemen Parkir Sekolah</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.11.1/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <div class="sidebar-logo-icon">
                <i class="bi bi-mortarboard-fill" style="color:white;"></i>
            </div>
            <h3><i class="bi bi-p-circle-fill"></i> SIMPAR</h3>
            <small>Parkir Sekolah Management</small>
        </div>
        <ul class="sidebar-menu">
            <li class="menu-label">Menu Utama</li>
            <li>
                <a href="index.php?page=dashboard" class="<?= ($page ?? '') === 'dashboard' ? 'active' : '' ?>">
                    <i class="bi bi-speedometer2"></i> Dashboard
                </a>
            </li>

            <?php if (getRole() === 'admin'): ?>
            <li class="menu-label">Master Data</li>
            <li>
                <a href="index.php?page=user" class="<?= ($page ?? '') === 'user' ? 'active' : '' ?>">
                    <i class="bi bi-people-fill"></i> Kelola User
                </a>
            </li>
            <li>
                <a href="index.php?page=tarif" class="<?= ($page ?? '') === 'tarif' ? 'active' : '' ?>">
                    <i class="bi bi-tags-fill"></i> Tarif Parkir
                </a>
            </li>
            <li>
                <a href="index.php?page=area_parkir" class="<?= ($page ?? '') === 'area_parkir' ? 'active' : '' ?>">
                    <i class="bi bi-geo-alt-fill"></i> Zona Parkir
                </a>
            </li>
            <li>
                <a href="index.php?page=kendaraan" class="<?= ($page ?? '') === 'kendaraan' ? 'active' : '' ?>">
                    <i class="bi bi-truck"></i> Data Kendaraan
                </a>
            </li>
            <li class="menu-label">Monitoring</li>
            <li>
                <a href="index.php?page=log" class="<?= ($page ?? '') === 'log' ? 'active' : '' ?>">
                    <i class="bi bi-clock-history"></i> Log Aktivitas
                </a>
            </li>
            <?php endif; ?>

            <?php if (getRole() === 'petugas'): ?>
            <li class="menu-label">Operasional</li>
            <li>
                <a href="index.php?page=transaksi" class="<?= ($page ?? '') === 'transaksi' ? 'active' : '' ?>">
                    <i class="bi bi-receipt"></i> Transaksi Parkir
                </a>
            </li>
            <?php endif; ?>

            <?php if (getRole() === 'owner'): ?>
            <li class="menu-label">Laporan</li>
            <li>
                <a href="index.php?page=rekap" class="<?= ($page ?? '') === 'rekap' ? 'active' : '' ?>">
                    <i class="bi bi-bar-chart-fill"></i> Rekap Transaksi
                </a>
            </li>
            <?php endif; ?>

            <li class="menu-label">Akun</li>
            <li>
                <a href="index.php?page=logout" style="color: #f87171;">
                    <i class="bi bi-box-arrow-left"></i> Logout
                </a>
            </li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Top Navbar -->
        <div class="top-navbar">
            <div class="page-title"><i class="bi bi-mortarboard-fill me-2" style="color:#d97706;"></i><?= $pageTitle ?? 'Dashboard' ?></div>
            <div class="user-info">
                <div class="user-detail" style="text-align:right;">
                    <span><?= $_SESSION['user']['nama_lengkap'] ?? '' ?></span>
                    <small><?= ucfirst($_SESSION['user']['role'] ?? '') ?></small>
                </div>
                <div class="avatar"><?= strtoupper(substr($_SESSION['user']['nama_lengkap'] ?? 'U', 0, 1)) ?></div>
            </div>
        </div>
        <div class="content-area">
            <?php if ($msg = flash('success')): ?>
                <div class="alert-custom alert-success"><i class="bi bi-check-circle-fill"></i> <?= $msg ?></div>
            <?php endif; ?>
            <?php if ($msg = flash('error')): ?>
                <div class="alert-custom alert-error"><i class="bi bi-exclamation-circle-fill"></i> <?= $msg ?></div>
            <?php endif; ?>
