<?php $pageTitle = 'Log Aktivitas'; require_once __DIR__ . '/../layouts/header.php'; ?>

<div class="card-custom">
    <div class="card-header-custom">
        <h5><i class="bi bi-clock-history"></i> Log Aktivitas</h5>
    </div>
    <div class="card-body-custom" style="overflow-x:auto;">
        <table class="table-custom">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Waktu</th>
                    <th>User</th>
                    <th>Role</th>
                    <th>Aktivitas</th>
                </tr>
            </thead>
            <tbody>
                <?php $no = 1; foreach ($logs as $l): ?>
                <tr>
                    <td><?= $no++ ?></td>
                    <td><small><?= date('d/m/Y H:i:s', strtotime($l['waktu_aktivitas'])) ?></small></td>
                    <td><strong><?= htmlspecialchars($l['nama_lengkap'] ?? '-') ?></strong></td>
                    <td><span class="badge-custom badge-primary"><?= ucfirst($l['role'] ?? '-') ?></span></td>
                    <td><?= htmlspecialchars($l['aktivitas']) ?></td>
                </tr>
                <?php endforeach; ?>
                <?php if (empty($logs)): ?>
                <tr><td colspan="5" class="text-center py-4" style="color:#94a3b8;">Belum ada log aktivitas</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once __DIR__ . '/../layouts/footer.php'; ?>
