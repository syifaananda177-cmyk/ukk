<?php $pageTitle = 'Tambah Kendaraan'; require_once __DIR__ . '/../layouts/header.php'; ?>

<div class="card-custom" style="max-width:600px;">
    <div class="card-header-custom">
        <h5><i class="bi bi-plus-circle-fill"></i> Tambah Kendaraan</h5>
    </div>
    <div class="card-body-custom">
        <form method="POST" action="index.php?page=kendaraan&action=store" class="form-custom">
            <div class="form-group">
                <label>Plat Nomor</label>
                <input type="text" name="plat_nomor" class="form-control" required placeholder="Contoh: D 1234 ABC" style="text-transform:uppercase;">
            </div>
            <div class="form-group">
                <label>Jenis Kendaraan</label>
                <select name="jenis_kendaraan" class="form-select" required>
                    <option value="">-- Pilih Jenis --</option>
                    <option value="motor">Motor</option>
                    <option value="mobil">Mobil</option>
                    <option value="lainnya">Lainnya</option>
                </select>
            </div>
            <div class="form-group">
                <label>Warna</label>
                <input type="text" name="warna" class="form-control" required placeholder="Contoh: Hitam">
            </div>
            <div class="form-group">
                <label>Pemilik</label>
                <input type="text" name="pemilik" class="form-control" required placeholder="Nama pemilik kendaraan">
            </div>
            <div class="form-group">
                <label>Didaftarkan Oleh (User)</label>
                <select name="id_user" class="form-select" required>
                    <option value="">-- Pilih User --</option>
                    <?php foreach ($users as $u): ?>
                    <option value="<?= $u['id_user'] ?>"><?= htmlspecialchars($u['nama_lengkap']) ?> (<?= $u['role'] ?>)</option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="d-flex gap-2">
                <button type="submit" class="btn-primary-custom"><i class="bi bi-save"></i> Simpan</button>
                <a href="index.php?page=kendaraan" class="btn-secondary-custom"><i class="bi bi-arrow-left"></i> Kembali</a>
            </div>
        </form>
    </div>
</div>

<?php require_once __DIR__ . '/../layouts/footer.php'; ?>
