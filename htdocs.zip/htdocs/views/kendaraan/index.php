<?php $pageTitle = 'Data Kendaraan'; require_once __DIR__ . '/../layouts/header.php'; ?>

<div class="card-custom">
    <div class="card-header-custom">
        <h5><i class="bi bi-truck"></i> Data Kendaraan</h5>
        <a href="index.php?page=kendaraan&action=create" class="btn-primary-custom"><i class="bi bi-plus-lg"></i> Tambah Kendaraan</a>
    </div>
    <div class="card-body-custom" style="overflow-x:auto;">
        <table class="table-custom">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Plat Nomor</th>
                    <th>Jenis</th>
                    <th>Warna</th>
                    <th>Pemilik</th>
                    <th>Didaftarkan Oleh</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $no = 1; foreach ($kendaraans as $k): ?>
                <tr>
                    <td><?= $no++ ?></td>
                    <td><strong><?= htmlspecialchars($k['plat_nomor']) ?></strong></td>
                    <td><span class="badge-custom badge-info"><?= ucfirst($k['jenis_kendaraan']) ?></span></td>
                    <td><?= htmlspecialchars($k['warna']) ?></td>
                    <td><?= htmlspecialchars($k['pemilik']) ?></td>
                    <td><?= htmlspecialchars($k['nama_lengkap'] ?? '-') ?></td>
                    <td>
                        <div class="btn-group-action">
                            <a href="index.php?page=kendaraan&action=edit&id=<?= $k['id_kendaraan'] ?>" class="btn-warning-custom"><i class="bi bi-pencil"></i></a>
                            <a href="index.php?page=kendaraan&action=delete&id=<?= $k['id_kendaraan'] ?>" class="btn-danger-custom" onclick="return confirm('Yakin hapus kendaraan ini?')"><i class="bi bi-trash"></i></a>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php if (empty($kendaraans)): ?>
                <tr><td colspan="7" class="text-center py-4" style="color:#94a3b8;">Belum ada data kendaraan</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once __DIR__ . '/../layouts/footer.php'; ?>
