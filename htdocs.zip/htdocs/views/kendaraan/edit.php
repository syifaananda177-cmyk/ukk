<?php $pageTitle = 'Edit Kendaraan'; require_once __DIR__ . '/../layouts/header.php'; ?>

<div class="card-custom" style="max-width:600px;">
    <div class="card-header-custom">
        <h5><i class="bi bi-pencil-square"></i> Edit Kendaraan</h5>
    </div>
    <div class="card-body-custom">
        <form method="POST" action="index.php?page=kendaraan&action=update&id=<?= $kendaraan['id_kendaraan'] ?>" class="form-custom">
            <div class="form-group">
                <label>Plat Nomor</label>
                <input type="text" name="plat_nomor" class="form-control" required value="<?= htmlspecialchars($kendaraan['plat_nomor']) ?>" style="text-transform:uppercase;">
            </div>
            <div class="form-group">
                <label>Jenis Kendaraan</label>
                <select name="jenis_kendaraan" class="form-select" required>
                    <option value="motor" <?= $kendaraan['jenis_kendaraan'] === 'motor' ? 'selected' : '' ?>>Motor</option>
                    <option value="mobil" <?= $kendaraan['jenis_kendaraan'] === 'mobil' ? 'selected' : '' ?>>Mobil</option>
                    <option value="lainnya" <?= $kendaraan['jenis_kendaraan'] === 'lainnya' ? 'selected' : '' ?>>Lainnya</option>
                </select>
            </div>
            <div class="form-group">
                <label>Warna</label>
                <input type="text" name="warna" class="form-control" required value="<?= htmlspecialchars($kendaraan['warna']) ?>">
            </div>
            <div class="form-group">
                <label>Pemilik</label>
                <input type="text" name="pemilik" class="form-control" required value="<?= htmlspecialchars($kendaraan['pemilik']) ?>">
            </div>
            <div class="form-group">
                <label>Didaftarkan Oleh (User)</label>
                <select name="id_user" class="form-select" required>
                    <?php foreach ($users as $u): ?>
                    <option value="<?= $u['id_user'] ?>" <?= $u['id_user'] == $kendaraan['id_user'] ? 'selected' : '' ?>>
                        <?= htmlspecialchars($u['nama_lengkap']) ?> (<?= $u['role'] ?>)
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="d-flex gap-2">
                <button type="submit" class="btn-primary-custom"><i class="bi bi-save"></i> Update</button>
                <a href="index.php?page=kendaraan" class="btn-secondary-custom"><i class="bi bi-arrow-left"></i> Kembali</a>
            </div>
        </form>
    </div>
</div>

<?php require_once __DIR__ . '/../layouts/footer.php'; ?>
