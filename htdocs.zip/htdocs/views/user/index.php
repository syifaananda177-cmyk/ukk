<?php $pageTitle = 'Kelola User'; require_once __DIR__ . '/../layouts/header.php'; ?>

<div class="card-custom">
    <div class="card-header-custom">
        <h5><i class="bi bi-people-fill"></i> Data User</h5>
        <a href="index.php?page=user&action=create" class="btn-primary-custom"><i class="bi bi-plus-lg"></i> Tambah User</a>
    </div>
    <div class="card-body-custom" style="overflow-x:auto;">
        <table class="table-custom">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama Lengkap</th>
                    <th>Username</th>
                    <th>Role</th>
                    <th>Status</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $no = 1; foreach ($users as $u): ?>
                <tr>
                    <td><?= $no++ ?></td>
                    <td><strong><?= htmlspecialchars($u['nama_lengkap']) ?></strong></td>
                    <td><?= htmlspecialchars($u['username']) ?></td>
                    <td><span class="badge-custom badge-primary"><?= ucfirst($u['role']) ?></span></td>
                    <td>
                        <?php if ($u['status_aktif']): ?>
                            <span class="badge-custom badge-success">Aktif</span>
                        <?php else: ?>
                            <span class="badge-custom badge-danger">Nonaktif</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <div class="btn-group-action">
                            <a href="index.php?page=user&action=edit&id=<?= $u['id_user'] ?>" class="btn-warning-custom"><i class="bi bi-pencil"></i></a>
                            <a href="index.php?page=user&action=delete&id=<?= $u['id_user'] ?>" class="btn-danger-custom" onclick="return confirm('Yakin hapus user ini?')"><i class="bi bi-trash"></i></a>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php if (empty($users)): ?>
                <tr><td colspan="6" class="text-center py-4" style="color:#94a3b8;">Belum ada data user</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once __DIR__ . '/../layouts/footer.php'; ?>
