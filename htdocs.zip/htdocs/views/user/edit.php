<?php $pageTitle = 'Edit User'; require_once __DIR__ . '/../layouts/header.php'; ?>

<div class="card-custom" style="max-width:600px;">
    <div class="card-header-custom">
        <h5><i class="bi bi-pencil-square"></i> Edit User</h5>
    </div>
    <div class="card-body-custom">
        <form method="POST" action="index.php?page=user&action=update&id=<?= $user['id_user'] ?>" class="form-custom">
            <div class="form-group">
                <label>Nama Lengkap</label>
                <input type="text" name="nama_lengkap" class="form-control" required value="<?= htmlspecialchars($user['nama_lengkap']) ?>">
            </div>
            <div class="form-group">
                <label>Username</label>
                <input type="text" name="username" class="form-control" required value="<?= htmlspecialchars($user['username']) ?>">
            </div>
            <div class="form-group">
                <label>Password <small class="text-muted">(kosongkan jika tidak diubah)</small></label>
                <input type="password" name="password" class="form-control" placeholder="Masukkan password baru">
            </div>
            <div class="form-group">
                <label>Role</label>
                <select name="role" class="form-select" required>
                    <option value="admin" <?= $user['role'] === 'admin' ? 'selected' : '' ?>>Admin</option>
                    <option value="petugas" <?= $user['role'] === 'petugas' ? 'selected' : '' ?>>Petugas</option>
                    <option value="owner" <?= $user['role'] === 'owner' ? 'selected' : '' ?>>Owner</option>
                </select>
            </div>
            <div class="form-group">
                <label class="d-flex align-items-center gap-2">
                    <input type="checkbox" name="status_aktif" <?= $user['status_aktif'] ? 'checked' : '' ?>> Status Aktif
                </label>
            </div>
            <div class="d-flex gap-2">
                <button type="submit" class="btn-primary-custom"><i class="bi bi-save"></i> Update</button>
                <a href="index.php?page=user" class="btn-secondary-custom"><i class="bi bi-arrow-left"></i> Kembali</a>
            </div>
        </form>
    </div>
</div>

<?php require_once __DIR__ . '/../layouts/footer.php'; ?>
