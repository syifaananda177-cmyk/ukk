<?php $pageTitle = 'Dashboard Admin Sekolah'; require_once __DIR__ . '/../layouts/header.php'; ?>

<div class="row g-4 mb-4">
    <div class="col-md-3">
        <div class="stat-card primary">
            <div class="stat-icon"><i class="bi bi-people-fill"></i></div>
            <div class="stat-value"><?= $data['total_user'] ?></div>
            <div class="stat-label">Total User</div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="stat-card success">
            <div class="stat-icon"><i class="bi bi-car-front-fill"></i></div>
            <div class="stat-value"><?= $data['total_kendaraan'] ?></div>
            <div class="stat-label">Total Kendaraan</div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="stat-card warning">
            <div class="stat-icon"><i class="bi bi-receipt"></i></div>
            <div class="stat-value"><?= $data['transaksi_aktif'] ?></div>
            <div class="stat-label">Kendaraan Terparkir</div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="stat-card info">
            <div class="stat-icon"><i class="bi bi-cash-stack"></i></div>
            <div class="stat-value">Rp <?= number_format($data['pendapatan_hari_ini']) ?></div>
            <div class="stat-label">Pendapatan Hari Ini</div>
        </div>
    </div>
</div>

<div class="card-custom">
    <div class="card-header-custom">
        <h5><i class="bi bi-geo-alt-fill"></i> Status Area Parkir</h5>
    </div>
    <div class="card-body-custom">
        <div class="row g-3">
            <?php foreach ($data['areas'] as $area):
                $persen = $area['kapasitas'] > 0 ? round(($area['terisi'] / $area['kapasitas']) * 100) : 0;
                $level = $persen < 50 ? 'low' : ($persen < 80 ? 'medium' : 'high');
            ?>
            <div class="col-md-4">
                <div class="p-3 rounded-3" style="background:#f8fafc;">
                    <div class="d-flex justify-content-between align-items-center">
                        <strong><?= htmlspecialchars($area['nama_area']) ?></strong>
                        <span class="badge-custom badge-<?= $level === 'low' ? 'success' : ($level === 'medium' ? 'warning' : 'danger') ?>">
                            <?= $area['terisi'] ?>/<?= $area['kapasitas'] ?>
                        </span>
                    </div>
                    <div class="area-progress">
                        <div class="progress-fill <?= $level ?>" style="width:<?= $persen ?>%"></div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../layouts/footer.php'; ?>
