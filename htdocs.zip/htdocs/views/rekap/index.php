<?php $pageTitle = 'Rekap Transaksi'; require_once __DIR__ . '/../layouts/header.php'; ?>

<div class="card-custom mb-4">
    <div class="card-header-custom">
        <h5><i class="bi bi-funnel"></i> Filter Rekap</h5>
    </div>
    <div class="card-body-custom">
        <form method="GET" action="index.php" class="row g-3 align-items-end">
            <input type="hidden" name="page" value="rekap">
            <div class="col-md-4">
                <label class="form-label fw-semibold">Tanggal Mulai</label>
                <input type="date" name="tanggal_mulai" class="form-control" value="<?= htmlspecialchars($tanggalMulai) ?>" style="border:2px solid #e2e8f0;border-radius:10px;padding:10px 14px;">
            </div>
            <div class="col-md-4">
                <label class="form-label fw-semibold">Tanggal Selesai</label>
                <input type="date" name="tanggal_selesai" class="form-control" value="<?= htmlspecialchars($tanggalSelesai) ?>" style="border:2px solid #e2e8f0;border-radius:10px;padding:10px 14px;">
            </div>
            <div class="col-md-4">
                <button type="submit" class="btn-primary-custom w-100"><i class="bi bi-search"></i> Tampilkan Rekap</button>
            </div>
        </form>
    </div>
</div>

<div class="row g-4 mb-4">
    <div class="col-md-6">
        <div class="stat-card success">
            <div class="stat-icon"><i class="bi bi-cash-stack"></i></div>
            <div class="stat-value">Rp <?= number_format($totalPendapatan) ?></div>
            <div class="stat-label">Total Pendapatan (<?= date('d/m/Y', strtotime($tanggalMulai)) ?> - <?= date('d/m/Y', strtotime($tanggalSelesai)) ?>)</div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="stat-card primary">
            <div class="stat-icon"><i class="bi bi-receipt"></i></div>
            <div class="stat-value"><?= count($transaksis) ?></div>
            <div class="stat-label">Total Transaksi Dalam Periode</div>
        </div>
    </div>
</div>

<div class="card-custom">
    <div class="card-header-custom">
        <h5><i class="bi bi-table"></i> Detail Transaksi</h5>
        <button onclick="window.print()" class="btn-primary-custom no-print"><i class="bi bi-printer"></i> Cetak</button>
    </div>
    <div class="card-body-custom" style="overflow-x:auto;">
        <table class="table-custom">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Plat Nomor</th>
                    <th>Jenis</th>
                    <th>Area</th>
                    <th>Masuk</th>
                    <th>Keluar</th>
                    <th>Durasi</th>
                    <th>Biaya</th>
                    <th>Status</th>
                    <th>Petugas</th>
                </tr>
            </thead>
            <tbody>
                <?php $no = 1; foreach ($transaksis as $t): ?>
                <tr>
                    <td><?= $no++ ?></td>
                    <td><strong><?= htmlspecialchars($t['plat_nomor']) ?></strong></td>
                    <td><span class="badge-custom badge-info"><?= ucfirst($t['jenis_kendaraan']) ?></span></td>
                    <td><?= htmlspecialchars($t['nama_area']) ?></td>
                    <td><small><?= date('d/m/Y H:i', strtotime($t['waktu_masuk'])) ?></small></td>
                    <td><small><?= $t['waktu_keluar'] ? date('d/m/Y H:i', strtotime($t['waktu_keluar'])) : '-' ?></small></td>
                    <td><?= $t['durasi_jam'] ? $t['durasi_jam'] . ' jam' : '-' ?></td>
                    <td><strong><?= $t['biaya_total'] ? 'Rp ' . number_format($t['biaya_total']) : '-' ?></strong></td>
                    <td>
                        <?php if ($t['status'] === 'masuk'): ?>
                            <span class="badge-custom badge-warning">Masuk</span>
                        <?php else: ?>
                            <span class="badge-custom badge-success">Keluar</span>
                        <?php endif; ?>
                    </td>
                    <td><?= htmlspecialchars($t['nama_lengkap'] ?? '-') ?></td>
                </tr>
                <?php endforeach; ?>
                <?php if (empty($transaksis)): ?>
                <tr><td colspan="10" class="text-center py-4" style="color:#94a3b8;">Tidak ada transaksi dalam periode ini</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once __DIR__ . '/../layouts/footer.php'; ?>
