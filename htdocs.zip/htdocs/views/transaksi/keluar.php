<?php $pageTitle = 'Proses Keluar'; require_once __DIR__ . '/../layouts/header.php'; ?>

<div class="card-custom" style="max-width:600px;">
    <div class="card-header-custom">
        <h5><i class="bi bi-box-arrow-right"></i> Konfirmasi Kendaraan Keluar</h5>
    </div>
    <div class="card-body-custom">
        <div class="mb-4 p-3 rounded-3" style="background:#f8fafc;">
            <div class="row">
                <div class="col-6 mb-3">
                    <small class="text-muted">Plat Nomor</small>
                    <div class="fw-bold"><?= htmlspecialchars($data['transaksi']['plat_nomor']) ?></div>
                </div>
                <div class="col-6 mb-3">
                    <small class="text-muted">Jenis</small>
                    <div><span class="badge-custom badge-info"><?= ucfirst($data['transaksi']['jenis_kendaraan']) ?></span></div>
                </div>
                <div class="col-6 mb-3">
                    <small class="text-muted">Area</small>
                    <div class="fw-bold"><?= htmlspecialchars($data['transaksi']['nama_area']) ?></div>
                </div>
                <div class="col-6 mb-3">
                    <small class="text-muted">Pemilik</small>
                    <div class="fw-bold"><?= htmlspecialchars($data['transaksi']['pemilik']) ?></div>
                </div>
                <div class="col-6 mb-3">
                    <small class="text-muted">Waktu Masuk</small>
                    <div class="fw-bold"><?= date('d/m/Y H:i', strtotime($data['transaksi']['waktu_masuk'])) ?></div>
                </div>
                <div class="col-6 mb-3">
                    <small class="text-muted">Waktu Keluar</small>
                    <div class="fw-bold"><?= date('d/m/Y H:i', strtotime($data['waktu_keluar'])) ?></div>
                </div>
            </div>
        </div>

        <div class="row mb-4">
            <div class="col-6">
                <div class="p-3 rounded-3 text-center" style="background:rgba(79,70,229,0.05);">
                    <small class="text-muted d-block">Durasi</small>
                    <strong style="font-size:24px;color:var(--primary);"><?= $data['durasi'] ?> Jam</strong>
                </div>
            </div>
            <div class="col-6">
                <div class="p-3 rounded-3 text-center" style="background:rgba(16,185,129,0.05);">
                    <small class="text-muted d-block">Total Biaya</small>
                    <strong style="font-size:24px;color:var(--success);">Rp <?= number_format($data['biaya']) ?></strong>
                </div>
            </div>
        </div>

        <div class="d-flex gap-2">
            <a href="index.php?page=transaksi&action=proses_keluar&id=<?= $data['transaksi']['id_parkir'] ?>" class="btn-primary-custom" onclick="return confirm('Konfirmasi kendaraan keluar?')">
                <i class="bi bi-check-lg"></i> Konfirmasi Keluar
            </a>
            <a href="index.php?page=transaksi" class="btn-secondary-custom"><i class="bi bi-arrow-left"></i> Kembali</a>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../layouts/footer.php'; ?>
