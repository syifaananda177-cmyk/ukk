<?php $pageTitle = 'Transaksi Parkir'; require_once __DIR__ . '/../layouts/header.php'; ?>

<div class="card-custom mb-4">
    <div class="card-header-custom">
        <h5><i class="bi bi-car-front-fill"></i> Kendaraan Terparkir Saat Ini</h5>
        <a href="index.php?page=transaksi&action=create" class="btn-primary-custom"><i class="bi bi-plus-lg"></i> Kendaraan Masuk</a>
    </div>
    <div class="card-body-custom" style="overflow-x:auto;">
        <table class="table-custom">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Plat Nomor</th>
                    <th>Jenis</th>
                    <th>Area</th>
                    <th>Waktu Masuk</th>
                    <th>Status</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $no = 1; foreach ($transaksiAktif as $t): ?>
                <tr>
                    <td><?= $no++ ?></td>
                    <td><strong><?= htmlspecialchars($t['plat_nomor']) ?></strong></td>
                    <td><span class="badge-custom badge-info"><?= ucfirst($t['jenis_kendaraan']) ?></span></td>
                    <td><?= htmlspecialchars($t['nama_area']) ?></td>
                    <td><small><?= date('d/m/Y H:i', strtotime($t['waktu_masuk'])) ?></small></td>
                    <td><span class="badge-custom badge-warning">Terparkir</span></td>
                    <td>
                        <a href="index.php?page=transaksi&action=keluar&id=<?= $t['id_parkir'] ?>" class="btn-success-custom"><i class="bi bi-box-arrow-right"></i> Keluar</a>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php if (empty($transaksiAktif)): ?>
                <tr><td colspan="7" class="text-center py-4" style="color:#94a3b8;">Tidak ada kendaraan terparkir</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<div class="card-custom">
    <div class="card-header-custom">
        <h5><i class="bi bi-receipt"></i> Riwayat Semua Transaksi</h5>
    </div>
    <div class="card-body-custom" style="overflow-x:auto;">
        <table class="table-custom">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Plat Nomor</th>
                    <th>Jenis</th>
                    <th>Area</th>
                    <th>Masuk</th>
                    <th>Keluar</th>
                    <th>Durasi</th>
                    <th>Biaya</th>
                    <th>Status</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $no = 1; foreach ($transaksis as $t): ?>
                <tr>
                    <td><?= $no++ ?></td>
                    <td><strong><?= htmlspecialchars($t['plat_nomor']) ?></strong></td>
                    <td><span class="badge-custom badge-info"><?= ucfirst($t['jenis_kendaraan']) ?></span></td>
                    <td><?= htmlspecialchars($t['nama_area']) ?></td>
                    <td><small><?= date('d/m/Y H:i', strtotime($t['waktu_masuk'])) ?></small></td>
                    <td><small><?= $t['waktu_keluar'] ? date('d/m/Y H:i', strtotime($t['waktu_keluar'])) : '-' ?></small></td>
                    <td><?= $t['durasi_jam'] ? $t['durasi_jam'] . ' jam' : '-' ?></td>
                    <td><strong><?= $t['biaya_total'] ? 'Rp ' . number_format($t['biaya_total']) : '-' ?></strong></td>
                    <td>
                        <?php if ($t['status'] === 'masuk'): ?>
                            <span class="badge-custom badge-warning">Masuk</span>
                        <?php else: ?>
                            <span class="badge-custom badge-success">Keluar</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <a href="index.php?page=transaksi&action=struk&id=<?= $t['id_parkir'] ?>" class="btn-info-custom"><i class="bi bi-printer"></i></a>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php if (empty($transaksis)): ?>
                <tr><td colspan="10" class="text-center py-4" style="color:#94a3b8;">Belum ada data transaksi</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once __DIR__ . '/../layouts/footer.php'; ?>
