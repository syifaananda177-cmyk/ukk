<?php $pageTitle = 'Struk Parkir'; require_once __DIR__ . '/../layouts/header.php'; ?>

<div class="d-flex justify-content-between align-items-center mb-3 no-print">
    <h5></h5>
    <div class="d-flex gap-2">
        <button onclick="window.print()" class="btn-primary-custom"><i class="bi bi-printer"></i> Cetak Struk</button>
        <a href="index.php?page=transaksi" class="btn-secondary-custom"><i class="bi bi-arrow-left"></i> Kembali</a>
    </div>
</div>

<div class="struk-container">
    <div class="struk-header">
        <h3><i class="bi bi-car-front-fill"></i> PARKIR SEKOLAH</h3>
        <p>Struk Parkir Resmi Sekolah</p>
    </div>
    <div class="struk-body">
        <div class="struk-row">
            <span class="label">No. Transaksi</span>
            <span class="value">#PKR-<?= str_pad($transaksi['id_parkir'], 5, '0', STR_PAD_LEFT) ?></span>
        </div>
        <div class="struk-row">
            <span class="label">Plat Nomor</span>
            <span class="value"><?= htmlspecialchars($transaksi['plat_nomor']) ?></span>
        </div>
        <div class="struk-row">
            <span class="label">Jenis Kendaraan</span>
            <span class="value"><?= ucfirst($transaksi['jenis_kendaraan']) ?></span>
        </div>
        <div class="struk-row">
            <span class="label">Warna</span>
            <span class="value"><?= htmlspecialchars($transaksi['warna']) ?></span>
        </div>
        <div class="struk-row">
            <span class="label">Pemilik</span>
            <span class="value"><?= htmlspecialchars($transaksi['pemilik']) ?></span>
        </div>
        <div class="struk-row">
            <span class="label">Area Parkir</span>
            <span class="value"><?= htmlspecialchars($transaksi['nama_area']) ?></span>
        </div>
        <div class="struk-row">
            <span class="label">Waktu Masuk</span>
            <span class="value"><?= date('d/m/Y H:i', strtotime($transaksi['waktu_masuk'])) ?></span>
        </div>
        <?php if ($transaksi['waktu_keluar']): ?>
        <div class="struk-row">
            <span class="label">Waktu Keluar</span>
            <span class="value"><?= date('d/m/Y H:i', strtotime($transaksi['waktu_keluar'])) ?></span>
        </div>
        <div class="struk-row">
            <span class="label">Durasi</span>
            <span class="value"><?= $transaksi['durasi_jam'] ?> Jam</span>
        </div>
        <div class="struk-row">
            <span class="label">Tarif/Jam</span>
            <span class="value">Rp <?= number_format($transaksi['tarif_per_jam']) ?></span>
        </div>
        <?php endif; ?>
        <div class="struk-row">
            <span class="label">Status</span>
            <span class="value">
                <?php if ($transaksi['status'] === 'masuk'): ?>
                    <span class="badge-custom badge-warning">Masuk</span>
                <?php else: ?>
                    <span class="badge-custom badge-success">Keluar</span>
                <?php endif; ?>
            </span>
        </div>
        <div class="struk-row">
            <span class="label">Petugas</span>
            <span class="value"><?= htmlspecialchars($transaksi['nama_lengkap']) ?></span>
        </div>
    </div>
    <?php if ($transaksi['biaya_total'] > 0): ?>
    <div class="struk-total">
        <div class="total-label">TOTAL BIAYA</div>
        <div class="total-value">Rp <?= number_format($transaksi['biaya_total']) ?></div>
    </div>
    <?php endif; ?>
    <div class="struk-footer">
        <p>Terima kasih, semoga aktivitas belajar-mengajar berjalan lancar</p>
        <p>Struk ini merupakan bukti parkir yang sah</p>
        <p style="margin-top:8px;"><?= date('d/m/Y H:i:s') ?></p>
    </div>
</div>

<?php require_once __DIR__ . '/../layouts/footer.php'; ?>
