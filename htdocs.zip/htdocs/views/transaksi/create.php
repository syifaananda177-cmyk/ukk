<?php $pageTitle = 'Kendaraan Masuk'; require_once __DIR__ . '/../layouts/header.php'; ?>

<div class="card-custom" style="max-width:600px;">
    <div class="card-header-custom">
        <h5><i class="bi bi-car-front-fill"></i> Input Kendaraan Masuk</h5>
    </div>
    <div class="card-body-custom">
        <form method="POST" action="index.php?page=transaksi&action=store" class="form-custom">
            <div class="form-group">
                <label>Kendaraan</label>
                <select name="id_kendaraan" class="form-select" required>
                    <option value="">-- Pilih Kendaraan --</option>
                    <?php foreach ($kendaraans as $k): ?>
                    <option value="<?= $k['id_kendaraan'] ?>"><?= htmlspecialchars($k['plat_nomor']) ?> - <?= htmlspecialchars($k['pemilik']) ?> (<?= ucfirst($k['jenis_kendaraan']) ?>)</option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label>Tarif</label>
                <select name="id_tarif" class="form-select" required>
                    <option value="">-- Pilih Tarif --</option>
                    <?php foreach ($tarifs as $t): ?>
                    <option value="<?= $t['id_tarif'] ?>"><?= ucfirst($t['jenis_kendaraan']) ?> - Rp <?= number_format($t['tarif_per_jam']) ?>/jam</option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label>Area Parkir</label>
                <select name="id_area" class="form-select" required>
                    <option value="">-- Pilih Area --</option>
                    <?php foreach ($areas as $a): ?>
                    <option value="<?= $a['id_area'] ?>" <?= $a['terisi'] >= $a['kapasitas'] ? 'disabled' : '' ?>>
                        <?= htmlspecialchars($a['nama_area']) ?> (Sisa: <?= $a['kapasitas'] - $a['terisi'] ?> slot)
                        <?= $a['terisi'] >= $a['kapasitas'] ? ' — PENUH' : '' ?>
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label>Waktu Masuk</label>
                <input type="text" class="form-control" value="<?= date('d/m/Y H:i:s') ?>" disabled>
                <small class="text-muted">Waktu masuk otomatis tercatat saat ini</small>
            </div>
            <div class="d-flex gap-2">
                <button type="submit" class="btn-primary-custom"><i class="bi bi-check-lg"></i> Proses Masuk</button>
                <a href="index.php?page=transaksi" class="btn-secondary-custom"><i class="bi bi-arrow-left"></i> Kembali</a>
            </div>
        </form>
    </div>
</div>

<?php require_once __DIR__ . '/../layouts/footer.php'; ?>
