<?php $pageTitle = 'Edit Zona Parkir'; require_once __DIR__ . '/../layouts/header.php'; ?>

<div class="card-custom" style="max-width:500px;">
    <div class="card-header-custom">
        <h5><i class="bi bi-pencil-square"></i> Edit Zona Parkir</h5>
    </div>
    <div class="card-body-custom">
        <form method="POST" action="index.php?page=area_parkir&action=update&id=<?= $area['id_area'] ?>" class="form-custom">
            <div class="form-group">
                <label>Nama Area</label>
                <input type="text" name="nama_area" class="form-control" required value="<?= htmlspecialchars($area['nama_area']) ?>">
            </div>
            <div class="form-group">
                <label>Kapasitas</label>
                <input type="number" name="kapasitas" class="form-control" required min="1" value="<?= $area['kapasitas'] ?>">
            </div>
            <div class="form-group">
                <label>Terisi</label>
                <input type="number" name="terisi" class="form-control" required min="0" value="<?= $area['terisi'] ?>">
            </div>
            <div class="d-flex gap-2">
                <button type="submit" class="btn-primary-custom"><i class="bi bi-save"></i> Update</button>
                <a href="index.php?page=area_parkir" class="btn-secondary-custom"><i class="bi bi-arrow-left"></i> Kembali</a>
            </div>
        </form>
    </div>
</div>

<?php require_once __DIR__ . '/../layouts/footer.php'; ?>
