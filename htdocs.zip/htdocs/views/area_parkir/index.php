<?php $pageTitle = 'Zona Parkir'; require_once __DIR__ . '/../layouts/header.php'; ?>

<div class="card-custom">
    <div class="card-header-custom">
        <h5><i class="bi bi-geo-alt-fill"></i> Data Zona Parkir</h5>
        <a href="index.php?page=area_parkir&action=create" class="btn-primary-custom"><i class="bi bi-plus-lg"></i> Tambah Area</a>
    </div>
    <div class="card-body-custom" style="overflow-x:auto;">
        <table class="table-custom">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama Area</th>
                    <th>Kapasitas</th>
                    <th>Terisi</th>
                    <th>Ketersediaan</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $no = 1; foreach ($areas as $a):
                    $persen = $a['kapasitas'] > 0 ? round(($a['terisi'] / $a['kapasitas']) * 100) : 0;
                ?>
                <tr>
                    <td><?= $no++ ?></td>
                    <td><strong><?= htmlspecialchars($a['nama_area']) ?></strong></td>
                    <td><?= $a['kapasitas'] ?></td>
                    <td><?= $a['terisi'] ?></td>
                    <td>
                        <div class="d-flex align-items-center gap-2">
                            <div class="area-progress" style="width:120px;">
                                <div class="progress-fill <?= $persen < 50 ? 'low' : ($persen < 80 ? 'medium' : 'high') ?>" style="width:<?= $persen ?>%"></div>
                            </div>
                            <small><?= $persen ?>%</small>
                        </div>
                    </td>
                    <td>
                        <div class="btn-group-action">
                            <a href="index.php?page=area_parkir&action=edit&id=<?= $a['id_area'] ?>" class="btn-warning-custom"><i class="bi bi-pencil"></i></a>
                            <a href="index.php?page=area_parkir&action=delete&id=<?= $a['id_area'] ?>" class="btn-danger-custom" onclick="return confirm('Yakin hapus area ini?')"><i class="bi bi-trash"></i></a>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php if (empty($areas)): ?>
                <tr><td colspan="6" class="text-center py-4" style="color:#94a3b8;">Belum ada data area parkir</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once __DIR__ . '/../layouts/footer.php'; ?>
