<?php $pageTitle = 'Tambah Zona Parkir'; require_once __DIR__ . '/../layouts/header.php'; ?>

<div class="card-custom" style="max-width:500px;">
    <div class="card-header-custom">
        <h5><i class="bi bi-plus-circle-fill"></i> Tambah Zona Parkir</h5>
    </div>
    <div class="card-body-custom">
        <form method="POST" action="index.php?page=area_parkir&action=store" class="form-custom">
            <div class="form-group">
                <label>Nama Area</label>
                <input type="text" name="nama_area" class="form-control" required placeholder="Contoh: Area A - Motor">
            </div>
            <div class="form-group">
                <label>Kapasitas</label>
                <input type="number" name="kapasitas" class="form-control" required min="1" placeholder="Jumlah slot parkir">
            </div>
            <div class="d-flex gap-2">
                <button type="submit" class="btn-primary-custom"><i class="bi bi-save"></i> Simpan</button>
                <a href="index.php?page=area_parkir" class="btn-secondary-custom"><i class="bi bi-arrow-left"></i> Kembali</a>
            </div>
        </form>
    </div>
</div>

<?php require_once __DIR__ . '/../layouts/footer.php'; ?>
