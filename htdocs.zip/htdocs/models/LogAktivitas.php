<?php
require_once __DIR__ . '/../config/database.php';

class LogAktivitas {
    private $conn;
    private $table = 'tb_log_aktivitas';

    public function __construct() {
        $db = new Database();
        $this->conn = $db->getConnection();
    }

    public function getAll() {
        $stmt = $this->conn->query("
            SELECT l.*, u.nama_lengkap, u.role
            FROM {$this->table} l
            LEFT JOIN tb_user u ON l.id_user = u.id_user
            ORDER BY l.waktu_aktivitas DESC
        ");
        return $stmt->fetchAll();
    }

    public function create($idUser, $aktivitas) {
        $stmt = $this->conn->prepare("INSERT INTO {$this->table} (id_user, aktivitas, waktu_aktivitas) VALUES (:id_user, :aktivitas, NOW())");
        return $stmt->execute([
            'id_user' => $idUser,
            'aktivitas' => $aktivitas
        ]);
    }
}
