<?php
require_once __DIR__ . '/../config/database.php';

class Transaksi {
    private $conn;
    private $table = 'tb_transaksi';

    public function __construct() {
        $db = new Database();
        $this->conn = $db->getConnection();
    }

    public function getAll() {
        $stmt = $this->conn->query("
            SELECT t.*, k.plat_nomor, k.jenis_kendaraan, k.pemilik, a.nama_area, tr.tarif_per_jam, u.nama_lengkap
            FROM {$this->table} t
            LEFT JOIN tb_kendaraan k ON t.id_kendaraan = k.id_kendaraan
            LEFT JOIN tb_area_parkir a ON t.id_area = a.id_area
            LEFT JOIN tb_tarif tr ON t.id_tarif = tr.id_tarif
            LEFT JOIN tb_user u ON t.id_user = u.id_user
            ORDER BY t.id_parkir DESC
        ");
        return $stmt->fetchAll();
    }

    public function getById($id) {
        $stmt = $this->conn->prepare("
            SELECT t.*, k.plat_nomor, k.jenis_kendaraan, k.pemilik, k.warna, a.nama_area, tr.tarif_per_jam, u.nama_lengkap
            FROM {$this->table} t
            LEFT JOIN tb_kendaraan k ON t.id_kendaraan = k.id_kendaraan
            LEFT JOIN tb_area_parkir a ON t.id_area = a.id_area
            LEFT JOIN tb_tarif tr ON t.id_tarif = tr.id_tarif
            LEFT JOIN tb_user u ON t.id_user = u.id_user
            WHERE t.id_parkir = :id
        ");
        $stmt->execute(['id' => $id]);
        return $stmt->fetch();
    }

    public function create($data) {
        $stmt = $this->conn->prepare("INSERT INTO {$this->table} (id_kendaraan, waktu_masuk, id_tarif, status, id_user, id_area) VALUES (:id_kendaraan, :waktu_masuk, :id_tarif, 'masuk', :id_user, :id_area)");
        $result = $stmt->execute($data);
        return $result ? $this->conn->lastInsertId() : false;
    }

    public function prosesKeluar($id, $waktuKeluar, $durasi, $biaya) {
        $stmt = $this->conn->prepare("UPDATE {$this->table} SET waktu_keluar=:waktu_keluar, durasi_jam=:durasi, biaya_total=:biaya, status='keluar' WHERE id_parkir=:id");
        return $stmt->execute([
            'waktu_keluar' => $waktuKeluar,
            'durasi' => $durasi,
            'biaya' => $biaya,
            'id' => $id
        ]);
    }

    public function getAktif() {
        $stmt = $this->conn->query("
            SELECT t.*, k.plat_nomor, k.jenis_kendaraan, k.pemilik, a.nama_area
            FROM {$this->table} t
            LEFT JOIN tb_kendaraan k ON t.id_kendaraan = k.id_kendaraan
            LEFT JOIN tb_area_parkir a ON t.id_area = a.id_area
            WHERE t.status = 'masuk'
            ORDER BY t.waktu_masuk DESC
        ");
        return $stmt->fetchAll();
    }

    public function getRekap($tanggalMulai, $tanggalSelesai) {
        $stmt = $this->conn->prepare("
            SELECT t.*, k.plat_nomor, k.jenis_kendaraan, k.pemilik, a.nama_area, tr.tarif_per_jam, u.nama_lengkap
            FROM {$this->table} t
            LEFT JOIN tb_kendaraan k ON t.id_kendaraan = k.id_kendaraan
            LEFT JOIN tb_area_parkir a ON t.id_area = a.id_area
            LEFT JOIN tb_tarif tr ON t.id_tarif = tr.id_tarif
            LEFT JOIN tb_user u ON t.id_user = u.id_user
            WHERE DATE(t.waktu_masuk) BETWEEN :mulai AND :selesai
            ORDER BY t.waktu_masuk DESC
        ");
        $stmt->execute(['mulai' => $tanggalMulai, 'selesai' => $tanggalSelesai]);
        return $stmt->fetchAll();
    }

    public function getTotalPendapatan($tanggalMulai, $tanggalSelesai) {
        $stmt = $this->conn->prepare("SELECT COALESCE(SUM(biaya_total), 0) as total FROM {$this->table} WHERE status='keluar' AND DATE(waktu_masuk) BETWEEN :mulai AND :selesai");
        $stmt->execute(['mulai' => $tanggalMulai, 'selesai' => $tanggalSelesai]);
        return $stmt->fetch()['total'];
    }

    public function countAll() {
        $stmt = $this->conn->query("SELECT COUNT(*) as total FROM {$this->table}");
        return $stmt->fetch()['total'];
    }

    public function countAktif() {
        $stmt = $this->conn->query("SELECT COUNT(*) as total FROM {$this->table} WHERE status='masuk'");
        return $stmt->fetch()['total'];
    }

    public function totalPendapatanHariIni() {
        $stmt = $this->conn->query("SELECT COALESCE(SUM(biaya_total), 0) as total FROM {$this->table} WHERE status='keluar' AND DATE(waktu_masuk) = CURDATE()");
        return $stmt->fetch()['total'];
    }
}
