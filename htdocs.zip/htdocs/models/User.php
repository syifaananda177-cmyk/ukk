<?php
require_once __DIR__ . '/../config/database.php';

class User {
    private $conn;
    private $table = 'tb_user';

    public function __construct() {
        $db = new Database();
        $this->conn = $db->getConnection();
    }

    public function getAll() {
        $stmt = $this->conn->query("SELECT * FROM {$this->table} ORDER BY id_user DESC");
        return $stmt->fetchAll();
    }

    public function getById($id) {
        $stmt = $this->conn->prepare("SELECT * FROM {$this->table} WHERE id_user = :id");
        $stmt->execute(['id' => $id]);
        return $stmt->fetch();
    }

    public function login($username, $password) {
        $stmt = $this->conn->prepare("SELECT * FROM {$this->table} WHERE username = :username AND password = MD5(:password) AND status_aktif = 1");
        $stmt->execute(['username' => $username, 'password' => $password]);
        return $stmt->fetch();
    }

    public function create($data) {
        $stmt = $this->conn->prepare("INSERT INTO {$this->table} (nama_lengkap, username, password, role, status_aktif) VALUES (:nama_lengkap, :username, MD5(:password), :role, :status_aktif)");
        return $stmt->execute($data);
    }

    public function update($id, $data) {
        if (!empty($data['password'])) {
            $stmt = $this->conn->prepare("UPDATE {$this->table} SET nama_lengkap=:nama_lengkap, username=:username, password=MD5(:password), role=:role, status_aktif=:status_aktif WHERE id_user=:id");
            $data['id'] = $id;
        } else {
            unset($data['password']);
            $stmt = $this->conn->prepare("UPDATE {$this->table} SET nama_lengkap=:nama_lengkap, username=:username, role=:role, status_aktif=:status_aktif WHERE id_user=:id");
            $data['id'] = $id;
        }
        return $stmt->execute($data);
    }

    public function delete($id) {
        $stmt = $this->conn->prepare("DELETE FROM {$this->table} WHERE id_user = :id");
        return $stmt->execute(['id' => $id]);
    }

    public function countAll() {
        $stmt = $this->conn->query("SELECT COUNT(*) as total FROM {$this->table}");
        return $stmt->fetch()['total'];
    }
}
