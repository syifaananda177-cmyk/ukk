<?php
require_once __DIR__ . '/../config/database.php';

class AreaParkir {
    private $conn;
    private $table = 'tb_area_parkir';

    public function __construct() {
        $db = new Database();
        $this->conn = $db->getConnection();
    }

    public function getAll() {
        $stmt = $this->conn->query("SELECT * FROM {$this->table} ORDER BY id_area ASC");
        return $stmt->fetchAll();
    }

    public function getById($id) {
        $stmt = $this->conn->prepare("SELECT * FROM {$this->table} WHERE id_area = :id");
        $stmt->execute(['id' => $id]);
        return $stmt->fetch();
    }

    public function create($data) {
        $stmt = $this->conn->prepare("INSERT INTO {$this->table} (nama_area, kapasitas, terisi) VALUES (:nama_area, :kapasitas, :terisi)");
        return $stmt->execute($data);
    }

    public function update($id, $data) {
        $stmt = $this->conn->prepare("UPDATE {$this->table} SET nama_area=:nama_area, kapasitas=:kapasitas, terisi=:terisi WHERE id_area=:id");
        $data['id'] = $id;
        return $stmt->execute($data);
    }

    public function delete($id) {
        $stmt = $this->conn->prepare("DELETE FROM {$this->table} WHERE id_area = :id");
        return $stmt->execute(['id' => $id]);
    }

    public function incrementTerisi($id) {
        $stmt = $this->conn->prepare("UPDATE {$this->table} SET terisi = terisi + 1 WHERE id_area = :id AND terisi < kapasitas");
        return $stmt->execute(['id' => $id]);
    }

    public function decrementTerisi($id) {
        $stmt = $this->conn->prepare("UPDATE {$this->table} SET terisi = terisi - 1 WHERE id_area = :id AND terisi > 0");
        return $stmt->execute(['id' => $id]);
    }
}
