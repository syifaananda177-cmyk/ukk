<?php
require_once __DIR__ . '/../config/database.php';

class Kendaraan {
    private $conn;
    private $table = 'tb_kendaraan';

    public function __construct() {
        $db = new Database();
        $this->conn = $db->getConnection();
    }

    public function getAll() {
        $stmt = $this->conn->query("SELECT k.*, u.nama_lengkap FROM {$this->table} k LEFT JOIN tb_user u ON k.id_user = u.id_user ORDER BY k.id_kendaraan DESC");
        return $stmt->fetchAll();
    }

    public function getById($id) {
        $stmt = $this->conn->prepare("SELECT * FROM {$this->table} WHERE id_kendaraan = :id");
        $stmt->execute(['id' => $id]);
        return $stmt->fetch();
    }

    public function getByPlatNomor($plat) {
        $stmt = $this->conn->prepare("SELECT * FROM {$this->table} WHERE plat_nomor = :plat");
        $stmt->execute(['plat' => $plat]);
        return $stmt->fetch();
    }

    public function create($data) {
        $stmt = $this->conn->prepare("INSERT INTO {$this->table} (plat_nomor, jenis_kendaraan, warna, pemilik, id_user) VALUES (:plat_nomor, :jenis_kendaraan, :warna, :pemilik, :id_user)");
        return $stmt->execute($data);
    }

    public function update($id, $data) {
        $stmt = $this->conn->prepare("UPDATE {$this->table} SET plat_nomor=:plat_nomor, jenis_kendaraan=:jenis_kendaraan, warna=:warna, pemilik=:pemilik, id_user=:id_user WHERE id_kendaraan=:id");
        $data['id'] = $id;
        return $stmt->execute($data);
    }

    public function delete($id) {
        $stmt = $this->conn->prepare("DELETE FROM {$this->table} WHERE id_kendaraan = :id");
        return $stmt->execute(['id' => $id]);
    }

    public function countAll() {
        $stmt = $this->conn->query("SELECT COUNT(*) as total FROM {$this->table}");
        return $stmt->fetch()['total'];
    }
}
