<?php
require_once __DIR__ . '/../config/database.php';

class Tarif {
    private $conn;
    private $table = 'tb_tarif';

    public function __construct() {
        $db = new Database();
        $this->conn = $db->getConnection();
    }

    public function getAll() {
        $stmt = $this->conn->query("SELECT * FROM {$this->table} ORDER BY id_tarif ASC");
        return $stmt->fetchAll();
    }

    public function getById($id) {
        $stmt = $this->conn->prepare("SELECT * FROM {$this->table} WHERE id_tarif = :id");
        $stmt->execute(['id' => $id]);
        return $stmt->fetch();
    }

    public function getByJenis($jenis) {
        $stmt = $this->conn->prepare("SELECT * FROM {$this->table} WHERE jenis_kendaraan = :jenis");
        $stmt->execute(['jenis' => $jenis]);
        return $stmt->fetch();
    }

    public function create($data) {
        $stmt = $this->conn->prepare("INSERT INTO {$this->table} (jenis_kendaraan, tarif_per_jam) VALUES (:jenis_kendaraan, :tarif_per_jam)");
        return $stmt->execute($data);
    }

    public function update($id, $data) {
        $stmt = $this->conn->prepare("UPDATE {$this->table} SET jenis_kendaraan=:jenis_kendaraan, tarif_per_jam=:tarif_per_jam WHERE id_tarif=:id");
        $data['id'] = $id;
        return $stmt->execute($data);
    }

    public function delete($id) {
        $stmt = $this->conn->prepare("DELETE FROM {$this->table} WHERE id_tarif = :id");
        return $stmt->execute(['id' => $id]);
    }
}
